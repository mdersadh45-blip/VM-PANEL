#!/usr/bin/env bash
#
# SKVM installer for CodeSandbox, GitHub Codespaces, and other restricted
# containers that do NOT have systemd/systemctl available.
#
# This script installs and starts the SKVM web application itself. It does
# NOT attempt to install Docker or LXC, and it will NOT pretend real
# container provisioning works here -- these environments typically don't
# grant the privileges (Docker socket, cgroups, LXC tooling) that real
# provisioning requires. The panel UI, auth, admin/user flows, API, and
# database all work normally; VM creation will queue and then fail cleanly
# with a real error if Docker/LXC are not actually reachable, exactly like
# it would on any other host that lacks those daemons.
#
# Safe to re-run: it will not delete the database, VMs, or settings.
#
set -euo pipefail

INSTALL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${INSTALL_DIR}"

log()  { echo -e "\033[1;34m[skvm]\033[0m $*"; }
warn() { echo -e "\033[1;33m[skvm][warn]\033[0m $*"; }
err()  { echo -e "\033[1;31m[skvm][error]\033[0m $*" >&2; }

# --------------------------------------------------------------- detection
ENVIRONMENT_KIND="restricted_container"
if [[ -n "${CODESANDBOX_SSE:-}" || -f /.codesandbox || -n "${CODESANDBOX_HOST:-}" ]]; then
  ENVIRONMENT_KIND="codesandbox"
elif [[ -n "${CODESPACES:-}" ]]; then
  ENVIRONMENT_KIND="github_codespaces"
elif [[ -n "${GITPOD_WORKSPACE_ID:-}" ]]; then
  ENVIRONMENT_KIND="gitpod"
fi
log "Detected environment: ${ENVIRONMENT_KIND}"
log "No systemd here -- this script starts SKVM directly in the foreground/background instead of installing a service."

DOCKER_OK="no"
LXC_OK="no"
command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1 && DOCKER_OK="yes"
command -v lxc-create >/dev/null 2>&1 && LXC_OK="yes"

if [[ "${DOCKER_OK}" == "no" && "${LXC_OK}" == "no" ]]; then
  warn "Neither a reachable Docker daemon nor LXC tooling was detected."
  warn "SKVM will run and let you explore the panel, but real VM/container"
  warn "provisioning will fail with a real, honest error until you run this"
  warn "on a host with Docker or LXC available (see install.sh for a VPS)."
fi

# ------------------------------------------------------------------ python
if ! command -v python3 >/dev/null 2>&1; then
  err "python3 is required but was not found. Most CodeSandbox/Codespaces"
  err "Node templates don't include it by default -- switch to a Python"
  err "template/devcontainer, or install python3 manually, then re-run this script."
  exit 1
fi

PY_VERSION="$(python3 -c 'import sys; print("%d.%d" % sys.version_info[:2])')"
log "Using python3 (${PY_VERSION})"

# --------------------------------------------------------------- virtualenv
if [[ ! -d venv ]]; then
  log "Creating Python virtual environment..."
  python3 -m venv venv
fi
log "Installing Python dependencies (this can take a minute)..."
./venv/bin/pip install --upgrade pip >/dev/null
./venv/bin/pip install -r requirements.txt

# ------------------------------------------------------------- environment
if [[ ! -f .env ]]; then
  log "Creating .env from .env.example (first install)..."
  cp .env.example .env
  SECRET=$(python3 -c "import secrets; print(secrets.token_hex(32))")
  sed -i.bak "s#SECRET_KEY=.*#SECRET_KEY=${SECRET}#" .env && rm -f .env.bak
  # CodeSandbox/Codespaces usually proxy a fixed internal port; 8000 is a
  # sane default but you can change APP_PORT in .env if it's already taken.
else
  log ".env already exists -- leaving your existing configuration untouched."
fi

mkdir -p data logs

# ------------------------------------------------------------- database
log "Initializing database (idempotent; existing data is preserved)..."
./venv/bin/python -c "
from app import create_app
app = create_app()
print('Database ready. Local node synced. Bootstrap admin ensured if none existed.')
"

# ------------------------------------------------------------------ start
PORT=$(grep -E '^APP_PORT=' .env | cut -d= -f2)
PORT="${PORT:-8000}"

log "Starting SKVM in the background (no systemd available here)..."
mkdir -p logs
nohup ./venv/bin/python run.py > logs/skvm.out 2>&1 &
SKVM_PID=$!
echo "${SKVM_PID}" > skvm.pid

sleep 2
if kill -0 "${SKVM_PID}" 2>/dev/null; then
  log "SKVM is running (pid ${SKVM_PID}), listening on port ${PORT}."
else
  err "SKVM did not stay running. Check logs/skvm.out for details:"
  tail -n 40 logs/skvm.out || true
  exit 1
fi

echo
log "Local URL: http://localhost:${PORT}"
if [[ "${ENVIRONMENT_KIND}" == "codesandbox" ]]; then
  log "In CodeSandbox, open the 'Ports' tab and click the forwarded port ${PORT} to get your public preview URL."
elif [[ "${ENVIRONMENT_KIND}" == "github_codespaces" ]]; then
  log "In Codespaces, check the 'Ports' panel for the forwarded URL for port ${PORT} (make it Public/Private as needed)."
fi
log "Bootstrap admin: admin@gmail.com / admin  (change this immediately after first login)"
if [[ "${DOCKER_OK}" == "no" && "${LXC_OK}" == "no" ]]; then
  warn "Reminder: real container provisioning is not available in this environment."
fi
echo
log "Manage the process manually (no systemctl here):"
log "  Stop:    kill \$(cat skvm.pid)"
log "  Restart: kill \$(cat skvm.pid); ./install-codesandbox.sh"
log "  Logs:    tail -f logs/skvm.out"
