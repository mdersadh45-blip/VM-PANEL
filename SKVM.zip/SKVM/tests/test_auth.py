def test_bootstrap_admin_created(app):
    with app.app_context():
        from app.models import User

        admin = User.query.filter_by(role="admin").first()
        assert admin is not None
        assert admin.email == "admin@gmail.com"


def test_login_success(client):
    resp = client.post(
        "/auth/login",
        data={"email": "admin@gmail.com", "password": "admin"},
        follow_redirects=True,
    )
    assert resp.status_code == 200


def test_login_wrong_password(client):
    resp = client.post(
        "/auth/login",
        data={"email": "admin@gmail.com", "password": "wrong"},
        follow_redirects=True,
    )
    assert b"Invalid email or password" in resp.data


def test_register_creates_user_role(client, app):
    client.post(
        "/auth/register",
        data={
            "email": "newuser@example.com",
            "password": "password123",
            "confirm_password": "password123",
        },
    )
    with app.app_context():
        from app.models import User

        u = User.query.filter_by(email="newuser@example.com").first()
        assert u is not None
        assert u.role == "user"


def test_register_password_mismatch(client):
    resp = client.post(
        "/auth/register",
        data={
            "email": "x@example.com",
            "password": "password123",
            "confirm_password": "different",
        },
        follow_redirects=True,
    )
    assert b"do not match" in resp.data


def test_default_admin_credentials_not_in_starter_page(client):
    resp = client.get("/")
    assert b"admin@gmail.com" not in resp.data
    assert b"admin" != resp.data  # trivial sanity


def test_password_is_hashed(app):
    with app.app_context():
        from app.models import User

        admin = User.query.filter_by(role="admin").first()
        assert admin.password_hash != "admin"
        assert admin.password_hash.startswith("$argon2")
