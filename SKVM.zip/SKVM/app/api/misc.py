import secrets
from datetime import datetime

from flask import Blueprint, request, jsonify, g

from app.extensions import db
from app.models import Settings, User, ApiKey, ActivityLog
from app.auth.utils import hash_password
from app.api.auth import api_login_required, api_admin_required

misc_bp = Blueprint("api_misc", __name__)


@misc_bp.route("/settings", methods=["GET"])
@api_login_required
def get_settings():
    settings = Settings.query.first()
    if g.api_user.is_admin:
        return jsonify(
            {
                "panel_name": settings.panel_name,
                "theme": settings.theme,
                "discord_url": settings.discord_url,
                "container_engine": settings.container_engine,
                "google_auth_enabled": settings.google_auth_enabled,
            }
        )
    return jsonify(settings.to_public_dict())


@misc_bp.route("/settings", methods=["PUT"])
@api_admin_required
def update_settings():
    settings = Settings.query.first()
    data = request.get_json(silent=True) or {}

    if "panel_name" in data:
        settings.panel_name = str(data["panel_name"])[:64]
    if "discord_url" in data:
        settings.discord_url = data["discord_url"] or None
    if "theme" in data and data["theme"] in ("dark", "light", "system"):
        settings.theme = data["theme"]
    if "container_engine" in data:
        if data["container_engine"] not in ("docker", "lxc"):
            return jsonify({"error": "container_engine must be docker or lxc"}), 400
        settings.container_engine = data["container_engine"]

    db.session.commit()
    db.session.add(ActivityLog(user_id=g.api_user.id, action="settings.updated_via_api", status="ok"))
    db.session.commit()
    return jsonify({"status": "ok"})


@misc_bp.route("/users", methods=["GET"])
@api_admin_required
def list_users():
    users = User.query.order_by(User.created_at.desc()).all()
    return jsonify([u.to_dict() for u in users])


@misc_bp.route("/api-keys", methods=["POST"])
@api_admin_required
def create_api_key():
    data = request.get_json(silent=True) or {}
    name = (data.get("name") or "unnamed")[:64]
    raw_key = "skvm_" + secrets.token_urlsafe(32)
    key = ApiKey(
        user_id=g.api_user.id,
        name=name,
        key_prefix=raw_key[:12],
        key_hash=hash_password(raw_key),
        is_admin_key=True,
    )
    db.session.add(key)
    db.session.commit()
    # One-time reveal: the raw key is only ever returned in this response.
    return jsonify({"id": key.id, "name": key.name, "key": raw_key}), 201


@misc_bp.route("/api-keys/<key_id>", methods=["DELETE"])
@api_admin_required
def revoke_api_key(key_id):
    key = ApiKey.query.get(key_id)
    if key is None:
        return jsonify({"error": "not found"}), 404
    key.revoked = True
    db.session.commit()
    return jsonify({"status": "revoked"})
