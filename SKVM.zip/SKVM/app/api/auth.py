from datetime import datetime
from functools import wraps

from flask import request, jsonify, g
from flask_login import current_user

from app.extensions import db
from app.models import ApiKey, User
from app.auth.utils import verify_password


def _resolve_api_key():
    header = request.headers.get("Authorization", "")
    if not header.startswith("Bearer "):
        return None
    raw_key = header[len("Bearer "):].strip()
    if not raw_key.startswith("skvm_"):
        return None
    prefix = raw_key[:12]
    candidates = ApiKey.query.filter_by(key_prefix=prefix, revoked=False).all()
    for key in candidates:
        if verify_password(key.key_hash, raw_key):
            key.last_used = datetime.utcnow()
            db.session.commit()
            return key
    return None


def api_login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if current_user.is_authenticated:
            g.api_user = current_user
            g.api_is_admin_key = False
            return view(*args, **kwargs)
        key = _resolve_api_key()
        if key is None:
            return jsonify({"error": "unauthorized"}), 401
        g.api_user = User.query.get(key.user_id)
        g.api_is_admin_key = key.is_admin_key
        return view(*args, **kwargs)

    return wrapped


def api_admin_required(view):
    @wraps(view)
    def inner(*args, **kwargs):
        user = g.get("api_user")
        if user is None or not user.is_admin:
            return jsonify({"error": "forbidden"}), 403
        return view(*args, **kwargs)

    return api_login_required(inner)
