"""
Real LXC provisioning backend. Every method shells out to the actual LXC
userspace tools (lxc-create, lxc-start, lxc-attach, lxc-info, lxc-cgroup,
lxc-destroy) using argv lists only -- never a concatenated shell string
built from user input (spec section 32).
"""
import shutil
import subprocess
import time

from app.models import OS_CATALOG
from app.services.provisioning.base import ProvisioningError, ProvisioningProvider


def _run(argv, timeout=60, input_data=None):
    try:
        proc = subprocess.run(
            argv,
            capture_output=True,
            timeout=timeout,
            input=input_data,
        )
        return {
            "exit_code": proc.returncode,
            "stdout": proc.stdout.decode("utf-8", "replace") if proc.stdout else "",
            "stderr": proc.stderr.decode("utf-8", "replace") if proc.stderr else "",
        }
    except FileNotFoundError as exc:
        raise ProvisioningError(f"Required LXC tool not found: {exc}")
    except subprocess.TimeoutExpired:
        raise ProvisioningError(f"Command timed out: {' '.join(argv)}")


def _container_name(vm):
    return f"skvm-{vm.id}"


class LXCProvider(ProvisioningProvider):
    engine_name = "lxc"

    def verify_available(self):
        for binary in ("lxc-create", "lxc-start", "lxc-stop", "lxc-attach", "lxc-info", "lxc-destroy"):
            if not shutil.which(binary):
                raise ProvisioningError(
                    f"Required LXC tool '{binary}' is not installed on this host."
                )

    # ---------------------------------------------------------------- create
    def create(self, vm, progress_cb=None):
        os_def = OS_CATALOG[vm.os_key]
        name = _container_name(vm)

        def report(msg):
            if progress_cb:
                progress_cb(msg)

        report(f"Creating LXC container using the {os_def['lxc_template']} template")
        argv = [
            "lxc-create",
            "-n", name,
            "-t", "download",
            "--",
            "-d", os_def["lxc_template"],
            "-r", os_def["lxc_release"],
            "-a", "amd64",
            "--no-validate",
        ]
        result = _run(argv, timeout=600)
        if result["exit_code"] != 0:
            raise ProvisioningError(f"lxc-create failed: {result['stderr'] or result['stdout']}")

        return name

    # --------------------------------------------------------------- control
    def start(self, vm):
        result = _run(["lxc-start", "-n", vm.container_id, "-d"], timeout=60)
        if result["exit_code"] != 0:
            raise ProvisioningError(f"lxc-start failed: {result['stderr']}")
        # Give init a moment to bring up networking before we probe it.
        time.sleep(2)

    def stop(self, vm):
        result = _run(["lxc-stop", "-n", vm.container_id], timeout=60)
        if result["exit_code"] != 0 and "not running" not in result["stderr"].lower():
            raise ProvisioningError(f"lxc-stop failed: {result['stderr']}")

    def restart(self, vm):
        self.stop(vm)
        self.start(vm)

    def delete(self, vm):
        _run(["lxc-stop", "-n", vm.container_id], timeout=30)
        result = _run(["lxc-destroy", "-n", vm.container_id], timeout=60)
        if result["exit_code"] != 0 and "does not exist" not in result["stderr"].lower():
            raise ProvisioningError(f"lxc-destroy failed: {result['stderr']}")

    def status(self, vm):
        if not vm.container_id:
            return "missing"
        result = _run(["lxc-info", "-n", vm.container_id, "-s"], timeout=15)
        if result["exit_code"] != 0:
            if "does not exist" in result["stderr"].lower():
                return "missing"
            return "error"
        if "RUNNING" in result["stdout"]:
            return "running"
        if "STOPPED" in result["stdout"]:
            return "stopped"
        return "error"

    # ------------------------------------------------------------- execution
    def execute(self, vm, command: list, timeout=60):
        if not isinstance(command, (list, tuple)):
            raise ProvisioningError("command must be an argv list, not a string")
        argv = ["lxc-attach", "-n", vm.container_id, "--", *command]
        result = _run(argv, timeout=timeout)
        return result

    def get_ip(self, vm):
        result = _run(["lxc-info", "-n", vm.container_id, "-iH"], timeout=15)
        if result["exit_code"] == 0:
            ip = result["stdout"].strip().splitlines()[0] if result["stdout"].strip() else None
            return ip or None
        return None

    def configure_resources(self, vm):
        # Applied via cgroups on the running container.
        mem_bytes = vm.ram_mb * 1024 * 1024
        r1 = _run(["lxc-cgroup", "-n", vm.container_id, "memory.limit_in_bytes", str(mem_bytes)])
        r2 = _run(["lxc-cgroup", "-n", vm.container_id, "cpu.cfs_quota_us", str(vm.cpu * 100000)])
        if r1["exit_code"] != 0 or r2["exit_code"] != 0:
            raise ProvisioningError(
                f"Failed to apply cgroup limits: {r1['stderr'] or r2['stderr']}"
            )

    # ------------------------------------------------------------- software
    def install_ssh(self, vm):
        steps = [
            (["apt-get", "update"], "apt-get update"),
            (
                ["apt-get", "install", "-y", "openssh-server", "sudo"],
                "install openssh-server",
            ),
            (["useradd", "-m", "-s", "/bin/bash", vm.username], "create user"),
            (["usermod", "-aG", "sudo", vm.username], "grant sudo"),
        ]
        for cmd, desc in steps:
            res = self.execute(vm, cmd, timeout=180)
            if res["exit_code"] not in (0, None):
                if cmd[0] == "useradd" and "already exists" in (res["stderr"] + res["stdout"]):
                    continue
                raise ProvisioningError(f"Step '{desc}' failed: {res['stderr'] or res['stdout']}")

        chpasswd = _run(
            ["lxc-attach", "-n", vm.container_id, "--", "chpasswd"],
            timeout=30,
            input_data=f"{vm.username}:{vm.password_plain}\n".encode(),
        )
        if chpasswd["exit_code"] not in (0, None):
            raise ProvisioningError("Failed to set account password via chpasswd")

        self.execute(vm, ["systemctl", "enable", "--now", "ssh"], timeout=60)
        check = self.execute(vm, ["pgrep", "-x", "sshd"], timeout=30)
        if check["exit_code"] != 0:
            raise ProvisioningError("sshd did not start inside the LXC container")
        return True

    def install_tmate(self, vm):
        install = self.execute(vm, ["apt-get", "install", "-y", "tmate"], timeout=180)
        if install["exit_code"] not in (0, None):
            raise ProvisioningError(f"Failed to install tmate: {install['stderr']}")

        sock_path = "/tmp/skvm-tmate.sock"
        self.execute(vm, ["rm", "-f", sock_path], timeout=15)
        new_session = self.execute(vm, ["tmate", "-S", sock_path, "new-session", "-d"], timeout=30)
        if new_session["exit_code"] not in (0, None):
            raise ProvisioningError(f"Failed to start tmate session: {new_session['stderr']}")

        wait_ready = self.execute(vm, ["tmate", "-S", sock_path, "wait", "tmate-ready"], timeout=60)
        if wait_ready["exit_code"] not in (0, None):
            raise ProvisioningError(f"tmate session did not become ready: {wait_ready['stderr']}")

        display = self.execute(vm, ["tmate", "-S", sock_path, "display", "-p", "#{tmate_ssh}"], timeout=30)
        ssh_line = display["stdout"].strip()
        if display["exit_code"] not in (0, None) or not ssh_line.startswith("ssh "):
            raise ProvisioningError(
                f"Could not retrieve tmate session string: {display['stderr'] or display['stdout']}"
            )

        vm.tmate_socket_path = sock_path
        return ssh_line
