from app.services.provisioning.docker_provider import DockerProvider
from app.services.provisioning.lxc_provider import LXCProvider

_providers = {
    "docker": DockerProvider(),
    "lxc": LXCProvider(),
}


def get_provider(engine: str):
    provider = _providers.get(engine)
    if provider is None:
        raise ValueError(f"Unknown provisioning engine: {engine}")
    return provider
