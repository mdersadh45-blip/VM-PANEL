from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user

from app.extensions import db
from app.models import VM, VMState, ActivityLog
from app.auth.utils import hash_password, verify_password

user_bp = Blueprint("user", __name__, url_prefix="/user")


def _log(action, status="ok", message=""):
    db.session.add(ActivityLog(user_id=current_user.id, action=action, status=status, message=message))
    db.session.commit()


@user_bp.before_request
@login_required
def _guard():
    pass


@user_bp.route("/dashboard")
def dashboard():
    my_vms = VM.query.filter(
        VM.owner_id == current_user.id, VM.status != VMState.DELETED
    ).all()
    running = sum(1 for v in my_vms if v.status == VMState.RUNNING)
    stopped = sum(1 for v in my_vms if v.status == VMState.STOPPED)
    return render_template(
        "user/dashboard.html", my_vms=my_vms, running=running, stopped=stopped
    )


@user_bp.route("/vms")
def my_vm():
    my_vms = VM.query.filter(
        VM.owner_id == current_user.id, VM.status != VMState.DELETED
    ).order_by(VM.created_at.desc()).all()
    return render_template("user/my_vm.html", vms=my_vms)


@user_bp.route("/vms/<vm_id>")
def vm_detail(vm_id):
    vm = VM.query.get_or_404(vm_id)
    if vm.owner_id != current_user.id:
        from flask import abort

        abort(403)  # never let a user view another user's VM
    return render_template("admin/vm_detail.html", vm=vm, is_admin_view=False)


@user_bp.route("/settings", methods=["GET", "POST"])
def settings_page():
    if request.method == "POST":
        current_password = request.form.get("current_password") or ""
        new_email = (request.form.get("new_email") or "").strip().lower()
        new_password = request.form.get("new_password") or ""
        confirm_password = request.form.get("confirm_password") or ""

        if not verify_password(current_user.password_hash, current_password):
            flash("Current password is incorrect.", "error")
            return redirect(url_for("user.settings_page"))

        from app.models import User

        if new_email and new_email != current_user.email:
            if User.query.filter_by(email=new_email).first():
                flash("That email is already in use.", "error")
                return redirect(url_for("user.settings_page"))
            current_user.email = new_email
            _log("user.email_changed")

        if new_password:
            if len(new_password) < 8:
                flash("New password must be at least 8 characters.", "error")
                return redirect(url_for("user.settings_page"))
            if new_password != confirm_password:
                flash("New password and confirmation do not match.", "error")
                return redirect(url_for("user.settings_page"))
            current_user.password_hash = hash_password(new_password)
            _log("user.password_changed")

        db.session.commit()
        flash("Account updated.", "success")
        return redirect(url_for("user.settings_page"))

    return render_template("user/settings.html")
