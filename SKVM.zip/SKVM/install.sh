#!/usr/bin/env bash
#
# SKVM installer.
# Detects the Linux distribution, installs dependencies, sets up a
# virtualenv, prepares the database, detects Docker/LXC, installs a
# systemd service, and starts the panel.
#
# Safe to re-run: it will not delete the database, VMs, containers, or
# settings on a second run. It updates code/deps and restarts the service.
#
set -euo pipefail

INSTALL_DIR="/opt/skvm"
SERVICE_NAME="skvm"
REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

log()  { echo -e "\033[1;34m[skvm]\033[0m $*"; }
warn() { echo -e "\033[1;33m[skvm][warn]\033[0m $*"; }
err()  { echo -e "\033[1;31m[skvm][error]\033[0m $*" >&2; }

# ---------------------------------------------------------------- privileges
if [[ "${EUID}" -ne 0 ]]; then
  err "Please run as root: sudo ./install.sh"
  exit 1
fi

# ------------------------------------------------------------ detect distro
if [[ -f /etc/os-release ]]; then
  . /etc/os-release
  DISTRO="${ID:-unknown}"
  DISTRO_VERSION="${VERSION_ID:-unknown}"
else
  DISTRO="unknown"
  DISTRO_VERSION="unknown"
fi
ARCH="$(uname -m)"
log "Detected distro: ${DISTRO} ${DISTRO_VERSION} (${ARCH})"

# --------------------------------------------------- detect environment kind
ENVIRONMENT_KIND="vps_or_local_linux"
if [[ -n "${CODESANDBOX_SSE:-}" || -f /.codesandbox ]]; then
  ENVIRONMENT_KIND="codesandbox"
elif [[ -f /.dockerenv ]] && ! command -v systemctl >/dev/null 2>&1; then
  ENVIRONMENT_KIND="restricted_container"
fi
log "Environment kind: ${ENVIRONMENT_KIND}"
if [[ "${ENVIRONMENT_KIND}" != "vps_or_local_linux" ]]; then
  warn "This environment does not look like a normal privileged Linux host."
  warn "SKVM's web application will still install and run here, but real"
  warn "Docker/LXC container provisioning requires a privileged VPS or bare-metal host."
fi

# ------------------------------------------------------------- dependencies
log "Installing system dependencies..."
if command -v apt-get >/dev/null 2>&1; then
  apt-get update -y
  apt-get install -y python3 python3-venv python3-pip curl git lxc lxc-templates \
    bridge-utils uidmap ca-certificates gnupg lsb-release || \
    warn "Some packages failed to install; continuing (LXC/Docker checks below will reflect this)."
elif command -v dnf >/dev/null 2>&1; then
  dnf install -y python3 python3-pip curl git lxc lxc-templates bridge-utils || \
    warn "Some packages failed to install."
else
  warn "Unsupported package manager. Please install Python 3.10+, pip, and (optionally) lxc manually."
fi

# ------------------------------------------------------------------- Docker
if ! command -v docker >/dev/null 2>&1; then
  log "Docker not found. Attempting install via get.docker.com ..."
  if curl -fsSL https://get.docker.com -o /tmp/get-docker.sh 2>/dev/null; then
    sh /tmp/get-docker.sh || warn "Docker installation script failed; install Docker manually if you plan to use the Docker engine."
    systemctl enable --now docker 2>/dev/null || true
  else
    warn "Could not reach get.docker.com (no network egress?). Skipping Docker auto-install."
  fi
else
  log "Docker already installed."
fi

# ---------------------------------------------------------------- app files
log "Preparing application directory at ${INSTALL_DIR} ..."
mkdir -p "${INSTALL_DIR}"
if [[ "${REPO_DIR}" != "${INSTALL_DIR}" ]]; then
  rsync -a --exclude 'data' --exclude 'logs' --exclude '.git' --exclude 'venv' \
    "${REPO_DIR}/" "${INSTALL_DIR}/" 2>/dev/null || cp -r "${REPO_DIR}/." "${INSTALL_DIR}/"
fi
mkdir -p "${INSTALL_DIR}/data" "${INSTALL_DIR}/logs"

# --------------------------------------------------------------- virtualenv
cd "${INSTALL_DIR}"
if [[ ! -d venv ]]; then
  log "Creating Python virtual environment..."
  python3 -m venv venv
fi
log "Installing Python dependencies..."
./venv/bin/pip install --upgrade pip >/dev/null
./venv/bin/pip install -r requirements.txt

# ------------------------------------------------------------- environment
if [[ ! -f .env ]]; then
  log "Creating .env from .env.example (first install)..."
  cp .env.example .env
  # Generate a real random secret key rather than the placeholder.
  SECRET=$(python3 -c "import secrets; print(secrets.token_hex(32))")
  sed -i "s#SECRET_KEY=.*#SECRET_KEY=${SECRET}#" .env
else
  log ".env already exists -- leaving your existing configuration untouched."
fi

# ------------------------------------------------------- database & bootstrap
log "Initializing database (idempotent; existing data is preserved)..."
./venv/bin/python -c "
import os
os.environ.setdefault('DATABASE_URL', 'sqlite:///${INSTALL_DIR}/data/skvm.db')
from app import create_app
app = create_app()
print('Database ready. Local node synced. Bootstrap admin ensured if none existed.')
"

# ------------------------------------------------------------- systemd unit
if command -v systemctl >/dev/null 2>&1; then
  log "Installing systemd service..."
  sed "s#/opt/skvm#${INSTALL_DIR}#g" "${INSTALL_DIR}/scripts/skvm.service" > /etc/systemd/system/${SERVICE_NAME}.service
  systemctl daemon-reload
  systemctl enable ${SERVICE_NAME}
  systemctl restart ${SERVICE_NAME}
  sleep 2
  systemctl --no-pager status ${SERVICE_NAME} || true
else
  warn "systemctl not available in this environment. Start SKVM manually with:"
  warn "  cd ${INSTALL_DIR} && ./venv/bin/gunicorn -w 2 -b 0.0.0.0:8000 run:app"
fi

# ----------------------------------------------------------------- summary
PORT=$(grep -E '^APP_PORT=' "${INSTALL_DIR}/.env" | cut -d= -f2 || echo 8000)
PORT="${PORT:-8000}"
IP=$(hostname -I 2>/dev/null | awk '{print $1}')
IP="${IP:-127.0.0.1}"

echo
log "SKVM installation complete."
log "Panel URL: http://${IP}:${PORT}"
log "Bootstrap admin: admin@gmail.com / admin  (change this immediately after first login)"
if [[ "${ENVIRONMENT_KIND}" != "vps_or_local_linux" ]]; then
  warn "Reminder: real container provisioning is not available in this environment kind (${ENVIRONMENT_KIND})."
fi
log "Manage the service with: systemctl {status|start|stop|restart} ${SERVICE_NAME}"
log "Logs: journalctl -u ${SERVICE_NAME} -f"
